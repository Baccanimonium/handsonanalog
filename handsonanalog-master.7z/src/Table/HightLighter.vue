<template>
  <div
    class="hightLighter"
    :style="hightLighterStyles"
    @keyup.up="closeNewDocumentList"
  />
</template>

<script>
export default {
  name: 'HightLighter',
  props: {
    coord: {
      type: Array,
      default: undefined
    }
  },

  computed: {
    hightLighterStyles () {
      if (!this.coord) {
        return {}
      }
      const [rowIndex, index] = this.coord
      const { children } = this.$el.parentElement
      const { clientHeight, children: rowChildren, offsetTop } = children[rowIndex + 2]
      const { clientWidth, offsetLeft } = rowChildren[index]
      console.log(this.coord)
      return {
        height: `${clientHeight}px`,
        width: `${clientWidth}px`,
        top: `${offsetTop}px`,
        left: `${offsetLeft}px`
      }

    },
  },
}
</script>

<style scoped>
  .hightLighter {
    background-color: #2c3e50;
    position: absolute;
  }

</style>
